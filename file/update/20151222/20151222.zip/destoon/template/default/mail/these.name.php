<?php
$names = array (
  'alert' => '贸易提醒',
  'ask' => '收到提问',
  'email' => '邮件发送',
  'email-default' => '邮件发送默认',
  'email-login' => '邮件发送30天未登录',
  'email-password' => '邮件发送会员密码(明文)',
  'emailcode' => '邮件验证码',
  'message' => '站内信转发',
  'messager' => '系统信使模板',
  'send' => '发送邮件模板',
  'welcome' => '欢迎信模板',
);
?>