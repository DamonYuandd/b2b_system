<?php
defined('IN_DESTOON') or exit('Access Denied');
file_del(DT_ROOT.'/include/announce.php');
file_del(DT_ROOT.'/module/modules.php');
file_del(DT_ROOT.'/sitemap/maps.php');
file_del(DT_ROOT.'/module/article/admin/template/tpl.php');
?>