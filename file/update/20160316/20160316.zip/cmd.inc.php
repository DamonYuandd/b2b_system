<?php
defined('IN_DESTOON') or exit('Access Denied');
file_del(DT_ROOT.'/file/script/kindeditor.js');
?>