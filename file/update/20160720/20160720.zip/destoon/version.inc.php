<?php
define('DT_VERSION', '6.0');
define('DT_RELEASE', '20160720');
?>